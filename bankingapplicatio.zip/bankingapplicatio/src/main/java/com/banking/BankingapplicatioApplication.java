package com.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingapplicatioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingapplicatioApplication.class, args);

	 
	
	}

}
