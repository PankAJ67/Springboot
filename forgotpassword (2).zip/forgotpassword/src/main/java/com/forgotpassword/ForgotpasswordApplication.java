package com.forgotpassword;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForgotpasswordApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForgotpasswordApplication.class, args);
	
	System.out.println("okkk");}

}
