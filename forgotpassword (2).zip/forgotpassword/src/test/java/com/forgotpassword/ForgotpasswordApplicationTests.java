package com.forgotpassword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForgotpasswordApplicationTests {

	@Test
	void contextLoads() {
	}

}
