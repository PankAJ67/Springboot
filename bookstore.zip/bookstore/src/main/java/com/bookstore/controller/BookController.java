package com.bookstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.bookstore.entity.Book;
import com.bookstore.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService service;

	@GetMapping("/")
	public String home() {
		System.out.println("ok");
		return "home";
	}



	@GetMapping("/availableBook")
	public String availableBook() {

		return "book_list";
	}

	@GetMapping("/getAllBook")
	public String getAllBook() {

		return "getAllBook";
	}

	
	@GetMapping("/bookRegister")
	public String bookRegister() {
		return "book_register";
	}
	@PostMapping("/save")
public String addBook(@ModelAttribute Book b) {
 service.save(b);
		return "home";
		
	}
	
}
